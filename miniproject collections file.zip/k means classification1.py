import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
import cv2
from test_image_feature_extraction import feature_extraction
from skimage import io, filters, color, measure
from scipy import ndimage
import glob
from sklearn.cluster import KMeans
from scipy.spatial import distance


def compare_Eucledean_distances(c1,c2,point):
    dist1 = distance.euclidean(c1,point)
    dist2 = distance.euclidean(c2,point)
    if(dist1 <= dist2):
        return 0
    else:
        return 1



df = pd.read_csv('new_blood_cell_measurements.csv')
#data_norm = (df - df.mean()) / (df.max() - df.min())
#print(dataset[0:3,:]);
X = df.iloc[1:, [7,8,9]].values

path = input("enter path of the test image...")
feature_extraction(path)

test_df = pd.read_csv('test_image_features.csv')
test_X= test_df.iloc[1:, [7,8,9]].values


kmeans = KMeans(n_clusters = 2, init = 'k-means++', max_iter=50, random_state = 42)
y_kmeans = kmeans.fit_predict(X)
#print(y_kmeans)


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(X[y_kmeans == 0, 0], X[y_kmeans == 0, 1],X[y_kmeans == 0, 2],c = 'yellow', label = 'uninfected cells')
ax.scatter(X[y_kmeans == 1, 0], X[y_kmeans == 1, 1],X[y_kmeans == 1, 2],c = 'blue', label = 'infectected cells')
print(kmeans.cluster_centers_)
ax.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1],kmeans.cluster_centers_[:, 2], c = 'black', label = 'Centroids')

ax.scatter(test_X[:,0],test_X[:,1], c = 'red', label= "new cells\' values")

ax.set_xlabel('minimum Intensities')
ax.set_ylabel('mean Intensities')
ax.set_zlabel('maximum Intensities')
plt.legend()
plt.show()


r, c = test_X.shape
output_arr=[]

for i in range(r):
    point = [test_X[i][0], test_X[i][1],test_X[i][2]]
    cluster_num = compare_Eucledean_distances(kmeans.cluster_centers_[0],kmeans.cluster_centers_[1],point)
    output_arr.append( cluster_num)

print("total count of cells: ",len(output_arr))
print("Total Infected cells count: ",sum(output_arr))
parasitemia = (sum(output_arr)/len(output_arr))*100
print("percentage of infection: ",parasitemia)






