import cv2

for i in range(1,56):
    filepath=r"C:\Users\kota achyuth tanay\Desktop\miniproject\cdc dataset\miniproject training dataset\Malaria_Photo (" + str(i) + ")" + ".jpg"
    img=cv2.imread(filepath)
    img_median = cv2.medianBlur(img, 5)
    filepath1 = r"C:\Users\kota achyuth tanay\Desktop\miniproject\cdc dataset\afterMedianFiltering\A_malariaPhoto (" + str(i) + ")" + ".jpg"
    cv2.imwrite(filepath1,img_median)
cv2.waitKey(0)
cv2.destroyAllWindows()
