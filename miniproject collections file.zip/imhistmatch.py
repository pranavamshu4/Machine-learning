import cv2
import numpy as np
import histogram as h
import cumulative_histogram as ch



def equalize_test_image_with_template():

    im = cv2.imread('test_blurred_image.jpg',1)
    im_ref = cv2.imread('template.jpg',1)

    B,G,R = cv2.split(im)
    B_ref,G_ref,R_ref = cv2.split(im_ref)

    #cv2.imshow('original image',im)
    #cv2.imshow('template image',im_ref)
    matched_channels=[]
    channels=[B,G,R]
    channels_ref = [B_ref,G_ref,R_ref]
    for img,img_ref in zip(channels,channels_ref):
        height = img.shape[0]
        width = img.shape[1]
        pixels = width * height
    
        height_ref = img_ref.shape[0]
        width_ref = img_ref.shape[1]
        pixels_ref = width_ref * height_ref
    
        hist = h.histogram(img)
        hist_ref = h.histogram(img_ref)
    
        cum_hist = ch.cumulative_histogram(hist)
        cum_hist_ref = ch.cumulative_histogram(hist_ref)
    
        prob_cum_hist = cum_hist / pixels
    
        prob_cum_hist_ref = cum_hist_ref / pixels_ref
    
        K = 256
        new_values = np.zeros((K))
    
        for a in np.arange(K):
            j = K - 1
            while True:
                new_values[a] = j
                j = j - 1
                if j < 0 or prob_cum_hist[a] > prob_cum_hist_ref[j]:
                    break
    
        for i in np.arange(height):
            for j in np.arange(width):
                a = img.item(i,j)
                b = new_values[a]
                img.itemset((i,j), b)
        matched_channels.append(img)
    

    colour_imhistmatch = cv2.merge(tuple(matched_channels))
    return colour_imhistmatch
