from skimage import io, filters, color, measure
from scipy import ndimage
import cv2
import numpy as np
import matplotlib.pyplot as plt
import glob



proplist= ['Area',
               'equivalent_diameter',
               'orientation',
               'MajorAxisLength',
               'MinorAxisLength',
               'Perimeter',
               'MinIntensity',
               'MeanIntensity',
               'MaxIntensity',
               'Perimeter',
               'Solidity'
               ]
pixels_to_um = 0.5
output_file = open('new_blood_cell_measurements.csv', 'w')
output_file.write('Grain no.' + ',' + ','.join(proplist) +'\n')


for i in range(1,3):
    path=r"C:/Users/kota achyuth tanay/Desktop/miniproject/cdc dataset/segmentation"+str(i)+"/*.jpg"
    for file in glob.glob(path):
        
        im = io.imread(file, as_gray=True)
        val = filters.threshold_otsu(im)
        drops = ndimage.binary_fill_holes(im < val)
        
        drops1=[[255 if value==True  else 0 for value in row] for row in drops]
        
        drops2= np.float32(drops1)
        #cv2.imshow("dro",drops)
        
        kernel = np.ones((3,3),np.uint8)
        
        surebg=cv2.dilate(drops2,kernel,iterations=5)
        #cv2.imshow("background",surebg)
        Invdrops= [[255-value for value in row] for row in drops1]
        Invdrops1= np.float32(Invdrops)
        #cv2.imshow("inv",Invdrops1)
        
        prefg=cv2.dilate(Invdrops1,kernel,iterations=2)
        surefg=np.float32([[255-value for value in row] for row in prefg])
        if(i==1):
            surefg=cv2.erode(surefg,kernel,iterations=3)
        elif(i==2):
            surefg=cv2.erode(surefg,kernel,iterations=2)
        '''
        in the erode step:
            for shiny, iterations=2  (i.e., i = 2)
            for non shiny, iterations=3  (i.e., i = 1)
        '''
        
        '''
        #opening = cv2.morphologyEx(Invdrops1,cv2.MORPH_OPEN,kernel, iterations = 2)
        dist_transform = cv2.distanceTransform(Invdrops1,cv2.DIST_L2,5)
        ret, surefg = cv2.threshold(dist_transform,0.7*dist_transform.max(),255,0)
        '''
        #cv2.imshow("foreground",surefg)
        
        surefg=np.uint8(surefg)
        surebg=np.uint8(surebg)
        
        unknown= cv2.subtract(surebg,surefg)
        
        ret3,markers= cv2.connectedComponents(surefg)
        
        markers+=10
        markers[unknown==255]=0
        img= cv2.imread(file)
        #_,_,image=cv2.split(img)
        image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        markers=cv2.watershed(img,markers)
        
        img[markers == -1]=[0,0,0]
        img2 = color.label2rgb(markers, bg_label=0)
        #cv2.imshow("overlay original image",img)
        #cv2.imshow("colored grains",img2)
        
        
        regions = measure.regionprops(markers,intensity_image=image)
          
        
        grain_number =1
        for region_props in regions:
            output_file.write(str(grain_number))
            for i,prop in enumerate(proplist):
                if(prop== 'Area'):
                    to_print = region_props[prop]*pixels_to_um**2
                elif(prop =='orientation'):
                    to_print = region_props[prop]*57.2958
                elif(prop.find('Intensity')<0):
                    to_print = region_props[prop]*pixels_to_um
                else:
                    to_print = region_props[prop]
                output_file.write(','+str(to_print))
            output_file.write('\n')
            grain_number +=1
        
            
        #cv2.waitKey(1)
output_file.close() 
